<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmpAttendMethods extends Model
{
    //
    protected $table = "employee_attend_methods";
}
