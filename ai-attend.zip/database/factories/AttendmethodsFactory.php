<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Attendmethods;
use Faker\Generator as Faker;

$factory->define(Attendmethods::class, function (Faker $faker) {
    return [
        //
    ];
});
